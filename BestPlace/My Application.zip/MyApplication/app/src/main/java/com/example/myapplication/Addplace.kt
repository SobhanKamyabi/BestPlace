package com.example.myapplication

import android.Manifest
import android.R.attr.*
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import com.example.myapplication.databinding.ActivityAddplaceBinding

import android.graphics.Color
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log

import ir.hamsaa.persiandatepicker.api.PersianPickerDate

import ir.hamsaa.persiandatepicker.api.PersianPickerListener

import ir.hamsaa.persiandatepicker.PersianDatePickerDialog

import androidx.appcompat.app.AlertDialog
import com.example.myapplication.database.DatabaseHandler
import com.example.myapplication.model.Bestplace
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

///gal 1313
//cam 2323
class Addplace : AppCompatActivity() {
    var imageadressloc:String?=null
    companion object {
        const val TAG="TAG"
    }
    lateinit var binding :ActivityAddplaceBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding= ActivityAddplaceBinding.inflate(LayoutInflater.from(this))
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener{
            onBackPressed()
            setResult(Activity.RESULT_CANCELED)
        }
        binding.textInputEdittextdate.showSoftInputOnFocus=false
        binding.textInputEdittextdate.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) return@setOnFocusChangeListener
            showdate()
        }
        binding.buttonchooseimage.setOnClickListener{
            AlertDialog.Builder(this).setTitle("choose photo")
                .setItems(arrayOf("from gallery","from camera")){
                    dialog,options->
                    when(options){
                        0->{
                            choosephotofromgallary()
                        }
                        1->{
                            choosephotobycamera()
                        }
                    }
                }.show()


        }

        binding.buttonsavelocation.setOnClickListener{
            val title=binding.textInputEdittexttitle.text.toString()
            val description=binding.textInputEdittextdescription.text.toString()
            val date=binding.textInputEdittextdate.text.toString()
            val location=binding.textInputEdittextlocation.text.toString()

            val mybestplace=Bestplace(title,imageadressloc!!,description,date,location,0.0,0.0)
            val db=DatabaseHandler(this)
            db.addplace(mybestplace)
            setResult(Activity.RESULT_OK)
            finish()
        }


}
    fun capturepictureBycamera(){
        val cameraintent=Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(cameraintent,2323)
    }

     fun choosephotobycamera(){
         Dexter.withContext(this).withPermissions(
             Manifest.permission.CAMERA)
             .withListener(object :MultiplePermissionsListener{
                 override fun onPermissionsChecked(report:  MultiplePermissionsReport?) {
                     if (report!!.areAllPermissionsGranted()){
                         capturepictureBycamera()

                     }
                 }

                 override fun onPermissionRationaleShouldBeShown(
                     p0: MutableList<PermissionRequest>?,
                     p1: PermissionToken?
                 ) {
                     showrational()
                 }
             }).check()
     }

    fun showrational(){
        AlertDialog.Builder(this).setTitle(" access to file and camera")
            .setPositiveButton("go to setting"){
                _,_ ->
            val settings=   Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            val uri= Uri.fromParts("package",packageName,null)
                settings.data=uri
                startActivity(settings)
            }
            .setNegativeButton("donot Permission")
            {dialog,_ ->finish()}
            .show()
    }
    fun choosephotofromgallary(){
        Dexter.withContext(this).withPermissions(Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.CAMERA)
            .withListener(object :MultiplePermissionsListener{
                override fun onPermissionsChecked(report:  MultiplePermissionsReport?) {
                   if (report!!.areAllPermissionsGranted()){
                      //capturepictureBycamera()
                     val galleryintent= Intent(Intent.ACTION_PICK,MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
                       startActivityForResult(galleryintent,1313)
                   }
                }

                override fun onPermissionRationaleShouldBeShown(
                    p0: MutableList<PermissionRequest>?,
                    p1: PermissionToken?
                ) {
                    showrational()
                }
            }).check()
    }
    fun showdate(){
       val picker = PersianDatePickerDialog(this)
            .setPositiveButtonString("Ok")
            .setNegativeButton("No")
            .setTodayButton("Today")
            .setTodayButtonVisible(true)
            .setMinYear(1300)
            .setMaxYear(PersianDatePickerDialog.THIS_YEAR)
            .setMaxMonth(PersianDatePickerDialog.THIS_MONTH)
            .setMaxDay(PersianDatePickerDialog.THIS_DAY)
            .setInitDate(1370, 3, 13)
            .setActionTextColor(Color.GRAY)
            .setTitleType(PersianDatePickerDialog.WEEKDAY_DAY_MONTH_YEAR)
            .setShowInBottomSheet(true)
            .setListener(object : PersianPickerListener {
                override fun onDateSelected(persianPickerDate: PersianPickerDate) {
                binding.textInputEdittextdate.setText(persianPickerDate?.persianLongDate.toString())
                    Log.d(
                        TAG,
                        "onDateSelected: " + persianPickerDate.persianLongDate
                    ) // دوشنبه  13  خرداد  1370


                }

                override fun onDismissed() {

                }
            })

        picker.show()

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode==Activity.RESULT_OK){
            if (requestCode==2323){
               val bitmapimage=data?.extras?.get("data")as Bitmap
                imageadressloc= saveimageinstorage(bitmapimage)
                binding.imageViewplace.setImageBitmap(bitmapimage)

            }
        }
        if (resultCode==Activity.RESULT_OK){
            if (requestCode==1313) {
               if (data!=null){
                   val contenturi=data.data
                 val imagebitmap= MediaStore.Images.Media.getBitmap(this.contentResolver,contenturi)
                   imageadressloc= saveimageinstorage(imagebitmap)
                   binding.imageViewplace.setImageBitmap(imagebitmap)
               }
            }
            }

    }
    fun saveimageinstorage(bitmap: Bitmap):String{
       val fileandpath=buildfile("test.jpg")
        try {
            val portal=buildoutputstream(fileandpath)

            bitmap.compress(Bitmap.CompressFormat.JPEG,100,portal)
            portal.flush()
            portal.close()
        }catch (ex:IOException){
            ex.printStackTrace()
        }
        return fileandpath.absolutePath

    }
    fun buildoutputstream(file: File):FileOutputStream{
        return  FileOutputStream(file)
    }
    fun buildfile(filename:String):File{
       return File(this.filesDir,filename)
    }

}














