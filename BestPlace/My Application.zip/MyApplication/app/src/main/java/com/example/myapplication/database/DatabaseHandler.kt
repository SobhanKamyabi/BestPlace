package com.example.myapplication.database

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.database.sqlite.SQLiteOpenHelper
import com.example.myapplication.model.Bestplace

class DatabaseHandler(context:Context)
    :SQLiteOpenHelper(context,"bestplace",null,1){
    companion object{
        const val TABLE_NAME="bestplacetable"
        const val KEY_ID="KEY_ID"
        const val KEY_TITLE="KEY_TITLE"
        const val KEY_IMAGE="KEY_IMAGE"
        const val KEY_DESCRIPTION="KEY_DESCRIPTION"
        const val KEY_DATE="KEY_DATE"
        const val KEY_LOCATION="KEY_LOCATION"
        const val KEY_LATITUDE="KEY_LATITUDE"
        const val KEY_LONGITUDE="KEY_LONGITUDE"

    }
    override fun onCreate(db: SQLiteDatabase?) {
        val createtablebestplace=("create table "+ TABLE_NAME +" ( "
                + KEY_ID + " text primary key, "
                + KEY_TITLE + " text, "
                + KEY_IMAGE + " text, "
                + KEY_DESCRIPTION + " text, "
                + KEY_DATE + " text, "
                + KEY_LOCATION + " text, "
                + KEY_LATITUDE + " text, "
                + KEY_LONGITUDE + " text )")
        db?.execSQL(createtablebestplace)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db!!.execSQL("drop table if exists ${TABLE_NAME}")
        onCreate(db)
    }

    fun addplace(bestplace: Bestplace){
        val writabledatabase=this.writableDatabase
        val contentValues=ContentValues()
        contentValues.put(KEY_ID,bestplace.id)
        contentValues.put(KEY_TITLE,bestplace.title)
        contentValues.put(KEY_IMAGE,bestplace.image)
        contentValues.put(KEY_DESCRIPTION,bestplace.description)
        contentValues.put(KEY_DATE,bestplace.date)
        contentValues.put(KEY_LOCATION,bestplace.Location)
        contentValues.put(KEY_LATITUDE,bestplace.latitude)
        contentValues.put(KEY_LONGITUDE,bestplace.longitude)
        writabledatabase.insert(TABLE_NAME,null,contentValues)
        writabledatabase.close()

    }
    fun getallplace():ArrayList<Bestplace> {
        val getAllQuery = "select * from ${TABLE_NAME}"
        val db = this.readableDatabase
        val bestplaseArray = ArrayList<Bestplace>()
        try {
            val cursor = db.rawQuery(getAllQuery, null)
            while (cursor.moveToNext()) {
                val bestplace = Bestplace(
                    cursor.getString(cursor.getColumnIndexOrThrow(KEY_TITLE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(KEY_IMAGE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(KEY_DESCRIPTION)),
                    cursor.getString(cursor.getColumnIndexOrThrow(KEY_DATE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(KEY_LOCATION)),
                    cursor.getString(cursor.getColumnIndexOrThrow(KEY_LATITUDE)).toDouble(),
                    cursor.getString(cursor.getColumnIndexOrThrow(KEY_LONGITUDE)).toDouble()
                )
                bestplace.id = cursor.getString(cursor.getColumnIndexOrThrow(KEY_ID))
                bestplaseArray.add(bestplace)
        }
            if (!cursor.isClosed) cursor.close()
        }catch (ex:SQLiteException){
            ex.printStackTrace()
        }

        db.close()
        return bestplaseArray
    }
}