package com.example.myapplication.list

import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.R
import com.example.myapplication.listener.OnRecycleviewitemlistener
import com.example.myapplication.model.Bestplace
import java.io.File

class Bestplaceadapter(var context: Context,var list: ArrayList<Bestplace>): RecyclerView.Adapter<Bestplaceadapter.bestplaceviewholder>() {
     var onRecycleviewitemlistener:OnRecycleviewitemlistener?=null
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): bestplaceviewholder {
    val view=LayoutInflater.from(context).inflate(R.layout.item_place,parent,false)
        return bestplaceviewholder(view)
    }

    override fun onBindViewHolder(holder: bestplaceviewholder, position: Int) {
       val bestplace=list.get(position)
        holder.textviewtitle.text=bestplace.title
        holder.textviewdate.text=bestplace.date
        holder.textviewloc.text=bestplace.Location
        Uri.parse(bestplace.image)
        val imagebitmap=MediaStore.Images.Media.getBitmap(context.contentResolver, Uri.fromFile(File(bestplace.image)))
        holder.imageplace.setImageBitmap(imagebitmap)
        holder.itemView.setOnClickListener{
     onRecycleviewitemlistener?.onbestPlaceItemClicked(position,bestplace)
        }

    }

    override fun getItemCount(): Int {
     return list.size
    }



    class bestplaceviewholder(itemView: View): RecyclerView.ViewHolder(itemView) {
       var textviewtitle:TextView
        lateinit var textviewdate:TextView
        lateinit var textviewloc:TextView
       var imageplace:ImageView

     init {
            textviewtitle=itemView.findViewById(R.id.textViewtitle)
            textviewdate=itemView.findViewById(R.id.textViewdate)
            textviewloc=itemView.findViewById(R.id.textViewlocation)
             imageplace=itemView.findViewById(R.id.imageViewplacelist)

          }
    }
fun setrecycleviewitemclick(onRecycleviewitemlistener: OnRecycleviewitemlistener){
    this.onRecycleviewitemlistener=onRecycleviewitemlistener
}

}