package com.example.myapplication.listener

import com.example.myapplication.model.Bestplace
import java.text.ParsePosition

interface OnRecycleviewitemlistener {
    fun onbestPlaceItemClicked(position: Int,bestplace: Bestplace)
}