package com.example.myapplication

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.widget.Button
import android.widget.LinearLayout
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.database.DatabaseHandler
import com.example.myapplication.databinding.ActivityMainBinding
import com.example.myapplication.list.Bestplaceadapter
import com.example.myapplication.listener.OnRecycleviewitemlistener
import com.example.myapplication.model.Bestplace
import java.util.*
import kotlin.math.log

class MainActivity : AppCompatActivity() {
    lateinit var binding:ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityMainBinding.inflate(LayoutInflater.from(this))
        setContentView(binding.root)
        setrecycleview()
        binding.floatingActionButtonMain.setOnClickListener {
            val intentToAddplace=Intent(this,Addplace::class.java)
            startActivityForResult(intentToAddplace,1212)
        }
        setSupportActionBar(binding.toolbar)


    }
fun setrecycleview(){
    val db=DatabaseHandler(this)
    val adapter=Bestplaceadapter(this,db.getallplace())
    binding.recycleviewmainplace.adapter=adapter
    binding.recycleviewmainplace.layoutManager=LinearLayoutManager(this)

}
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode==Activity.RESULT_OK){
            if (requestCode==1212){
                setrecycleview()
            }
        }
    }

}