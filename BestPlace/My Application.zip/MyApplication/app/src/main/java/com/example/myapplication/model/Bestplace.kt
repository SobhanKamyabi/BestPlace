package com.example.myapplication.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import java.util.*
@Parcelize
class Bestplace constructor(
    var title: String,
    var image: String,
    var description: String,
    var date: String,
    var Location: String,
    var latitude: Double,
    var longitude: Double,
        ):Parcelable{
    var id:String?=null

    init {
        this.id=UUID.randomUUID().toString()
    }
}